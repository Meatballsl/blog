<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>详情</title>
</head>

<body>
<div>
    <form method="post" action="<?php echo e(url('newstock')); ?>">
        <?php echo e(csrf_field()); ?>


        <label>股票名称：</label>
        <input type="text" name="name">

        <button type="submit">添加新股票</button>

    </form>
</div>
<div>
    <ol>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>

                <a href="<?php echo e(url('detail?stock_number='.$value->id)); ?>"><?php echo e($value->name); ?></a>

            </li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
</div>

</body>
</html>
