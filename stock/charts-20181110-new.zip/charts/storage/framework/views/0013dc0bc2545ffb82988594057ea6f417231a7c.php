<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>详情</title>
</head>

<body>
<div><a href="<?php echo e(url('stock')); ?>"> 返回股票列表 </a></div>
<div>
    <form method="post" action="<?php echo e(url('newstock')); ?>">
        <?php echo e(csrf_field()); ?>


        <label>股票名称：</label>
        <input type="text" name="name">
        <input type="hidden" name="category_id" value="<?php echo e($category_id); ?>">
        <button type="submit">添加新股票:<?php echo e($category_id); ?></button>

    </form>
</div>
<div>
    <ol>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>

                <a href="<?php echo e(url('detail?stock_number='.$value->id)); ?>"><?php echo e($value->name); ?></a>

            </li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
</div>

</body>
</html>
