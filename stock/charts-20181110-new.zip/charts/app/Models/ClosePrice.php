<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClosePrice extends Model
{
    protected $table = 'closeprice';

    public $timestamps = false;
}