<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HkIncome extends Model
{
    protected $table = 'hkincome';

    public $timestamps = false;
}