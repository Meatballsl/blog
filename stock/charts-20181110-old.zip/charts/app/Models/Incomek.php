<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Incomek extends Model
{
    protected $table = 'incomek';

    public $timestamps = false;
}